from django.http import HttpResponseRedirect
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.mail import send_mail
from smanagement.models import *
from django.contrib import messages
from datetime import date
today = date.today()
import string    
import random # define the random module  
import os

# login page TODO
def index(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        return redirect('/administrator/dashboard')
    elif Staff.objects.filter(s_id=temp_id, type='Reception').exists() :
        return redirect('/reception/dashboard')
    elif Staff.objects.filter(s_id=temp_id, type='Placement').exists() :
        return redirect('/placement/dashboard')
    elif Student.objects.filter(s_id=temp_id).exists():
        return redirect('/student/dashboard')
    else:
        # return redirect('/')
        return render(request, "index.html")
    
# admin pages
# TODO
@login_required(login_url='/')
def admin_dashboard(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        admin_name = Profile.objects.all().last()
        staff_count = Staff.objects.all().count()
        student_count = Student.objects.all().count()
        course_count = Course.objects.all().count()
        feedback_count = Feedback.objects.all().count()
        if Notice.objects.all().count() > 0 :
            notice = Notice.objects.all().last()
        else:
            notice = ''
        context = {
                   'admin_name' : admin_name.name, 
                   'staff_count' : staff_count, 
                   'student_count' : student_count,
                   'course_count' : course_count,
                   'feedback_count' : feedback_count ,
                   'notice' : notice
                 }

        return render(request, "admin/dashboard.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_course(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Course.objects.all().order_by('-id')
        context = {'row' : row}
        return render(request, "admin/course.html", context)
    return redirect('/')
    
 #TODO   
@login_required(login_url='/')
def admin_feedback(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Feedback.objects.all().order_by('-id')
        context = {'row' : row}
        return render(request, "admin/feedback.html", context)
    return redirect('/')


@login_required(login_url='/')
def admin_fees(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Student.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "admin/fees.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_marks(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Exam.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "admin/marks.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_notice(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Notice.objects.all().order_by('-id')
        context = {'row' : row}
        return render(request, "admin/notice.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_profile(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        # TODO
        row = Profile.objects.get(id=1)
        context = {'row' : row }
        return render(request, "admin/profile.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_staff(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Staff.objects.all().order_by('-id')
        context = {'row' : row}
        return render(request, "admin/staff.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_staffprofileview(request, pk):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Staff.objects.get(id=pk)
    
        context = {'row' : row}
        return render(request, "admin/staffprofileview.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def admin_stdmarks(request, course, sem, exam_id):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Student.objects.filter(course=course, semester=sem).order_by('-id')
        context = {'row' : row, 'exam_id' : exam_id}
        return render(request, "admin/stdmarks.html", context)
    return redirect('/')

@login_required(login_url='/')
def admin_student(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Student.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        #TODO
        # course = Course.objects.get(name='FAF')
        # course_sem = int(course.total_sem) + 1
    
        context = {'row' : row, 'row2' : row2 }
        return render(request, "admin/student.html", context)
    return redirect('/')

@login_required(login_url='/')
def admin_stdprofileview(request, pk):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Student.objects.get(id=pk)
    
        context = {'row' : row}
        return render(request, "admin/stdprofileview.html", context)
    return redirect('/')

@login_required(login_url='/')
def admin_subject(request):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Subject.objects.all().order_by('-id')
        context = {'row' : row}
        row2 = Course.objects.all().order_by('-id')
        #TODO
        context = {'row' : row, 'row2' : row2 }
        return render(request, "admin/subject.html", context)
    return redirect('/')

@login_required(login_url='/')
def admin_mark_details(request, exam_id, s_id):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Marksheet.objects.filter(exam_id=exam_id, s_id=s_id).order_by('-id')
        context = {'row' : row}
        return render(request, "admin/mark_details.html", context)
    return redirect('/')

@login_required(login_url='/')
def admin_fee_details(request, pk):
    temp_id = request.user.username
    if Profile.objects.filter(login_id=temp_id).exists():
        row = Fees.objects.filter(s_id=pk).order_by('-id')
        context = {'row' : row}
        return render(request, "admin/fee_details.html", context)
    return redirect('/')

#reception pages
@login_required(login_url='/')
def reception_dashboard(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        reception = Staff.objects.get(s_id=temp_id)
        student_count = Student.objects.all().count()
        exam_count = Exam.objects.all().count()
        notice_count = Notice.objects.all().count()
        feedback_count = Feedback.objects.all().count()
        if Notice.objects.all().count() > 0 :
            notice = Notice.objects.all().last()
        else:
            notice = ''
        # TODO
        context = {
                   'reception_name' : reception.name, 
                   'student_count' : student_count,
                   'exam_count' : exam_count, 
                   'notice_count' : notice_count,
                   'feedback_count' : feedback_count ,
                   'notice' : notice
                 }
        return render(request, "reception/dashboard.html", context)
    return redirect('/')

@login_required(login_url='/')
def reception_exam(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Exam.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "reception/exam.html", context)
    return redirect('/')
        
@login_required(login_url='/')
def reception_feedback(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Feedback.objects.all().order_by('-id')
        context = {'row' : row}
        return render(request, "reception/feedback.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def reception_fees(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Student.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "reception/fees.html", context)
    return redirect('/')
        
@login_required(login_url='/')
def reception_marks(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Exam.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "reception/marks.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def reception_notice(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Notice.objects.all().order_by('-id')
        context = {'row' : row }
        return render(request, "reception/notice.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def reception_profile(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Staff.objects.get(s_id=temp_id)
        context = {'row' : row}
        return render(request, "reception/profile.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def reception_student(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Student.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        #TODO
        # course = Course.objects.get(name='FAF')
        # course_sem = int(course.total_sem) + 1
    
        context = {'row' : row, 'row2' : row2 }
        return render(request, "reception/student.html", context)
    return redirect('/')

@login_required(login_url='/')
def reception_stdmarks(request, course , sem, exam_id):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Student.objects.filter(course=course, semester=sem).order_by('-id')
        subjects = Subject.objects.filter(course=course, semester=sem).order_by('-id')
        context = {
                    'row' : row,
                    'subjects' : subjects,
                    'exam_id' : exam_id
                  }
        return render(request, "reception/stdmarks.html", context)
    return redirect('/')

@login_required(login_url='/')
def reception_viewmarks(request, exam_id, s_id):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Marksheet.objects.filter(exam_id=exam_id, s_id=s_id).order_by('-id')
        context = {'row' : row}
        return render(request, "reception/viewmarks.html", context)
    return redirect('/')

@login_required(login_url='/')
def reception_fee_details(request, pk):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
        row = Fees.objects.filter(s_id=pk).order_by('-id')
        context = {'row' : row}
        return render(request, "reception/fee_details.html", context)
    return redirect('/')

#placement pages
@login_required(login_url='/')
def placement_dashboard(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        placement = Staff.objects.get(s_id=temp_id)
        student_count = Student.objects.all().count()
        exam_count = Exam.objects.all().count()
        notice_count = Notice.objects.all().count()
        feedback_count = Feedback.objects.all().count()
        if Notice.objects.all().count() > 0 :
            notice = Notice.objects.all().last()
        else:
            notice = ''
        context = {
                   'placement_name' : placement.name, 
                   'student_count' : student_count,
                   'exam_count' : exam_count,
                   'notice_count' : notice_count,
                   'feedback_count' : feedback_count ,
                   'notice' : notice
                 }
        return render(request, "placement/dashboard.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_profile(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Staff.objects.get(s_id=temp_id)
        context = {'row' : row}
        return render(request, "placement/profile.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_student(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Student.objects.all().order_by('-active')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "placement/student.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_marks(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Exam.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "placement/marks.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_fees(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Student.objects.all().order_by('-id')
        row2 = Course.objects.all().order_by('-id')
        context = {'row' : row, 'row2' : row2}
        return render(request, "placement/fees.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_stdmarks(request, course, sem, exam_id):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Student.objects.filter(course=course, semester=sem).order_by('-id')
        context = {'row' : row, 'exam_id' : exam_id}
        return render(request, "placement/stdmarks.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_mark_details(request, exam_id, s_id):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Marksheet.objects.filter(exam_id=exam_id, s_id=s_id).order_by('-id')
        context = {'row' : row}
        return render(request, "placement/mark_details.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_fee_details(request, pk):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Fees.objects.filter(s_id=pk).order_by('-id')
        context = {'row' : row}
        return render(request, "placement/fee_details.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_notice(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Notice.objects.all().order_by('-id')
        context = {'row' : row }
        return render(request, "placement/notice.html", context)
    return redirect('/')

@login_required(login_url='/')
def placement_feedback(request):
    temp_id = request.user.username
    if Staff.objects.filter(s_id=temp_id, type='Placement').exists():
        row = Feedback.objects.all().order_by('-id')
        context = {'row' : row}
        return render(request, "placement/feedback.html", context)
    return redirect('/')

#student pages TODO
@login_required(login_url='/')
def student_dashboard(request):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        row = Student.objects.get(s_id=temp_id)
        total_feedback =  Feedback.objects.filter(s_id=temp_id).count()
        total_exam =  Exam.objects.filter(course=row.course, semester=row.semester).all().count()
        total_notice =  Notice.objects.all().count()
        if Notice.objects.all().count() > 0 :
            notice = Notice.objects.all().last()
        else:
            notice = ''
        context = {
                'row' : row ,
                'notice': notice,
                'total_exam': total_exam,
                'total_notice': total_notice,
                'total_feedback': total_feedback
                }
        return render(request, "student/dashboard.html", context)
    return redirect('/')

@login_required(login_url='/')
def student_feedback(request):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        row = Feedback.objects.filter(s_id=temp_id).order_by('-id')
        context = {'row' : row }
        return render(request, "student/feedback.html", context)
    return redirect('/')

@login_required(login_url='/')
def student_fees(request):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        row = Student.objects.get(s_id=temp_id)
        row2 = Fees.objects.filter(s_id=row.id).order_by('-id')
        context = {'row' : row2 }
        return render(request, "student/fees.html", context)
    return redirect('/')

@login_required(login_url='/')
def student_marks(request):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        student = Student.objects.get(s_id=temp_id)
        row = Exam.objects.filter(course=student.course, semester=student.semester).order_by('-id')
        context = {'row' : row}
        return render(request, "student/marks.html", context)
    return redirect('/')
    
@login_required(login_url='/')
def student_notice(request):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        row = Notice.objects.all().order_by('-id')
        context = {'row' : row }
        return render(request, "student/notice.html", context)
    return redirect('/')

#TODO
@login_required(login_url='/')
def student_profile(request):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        row = Student.objects.get(s_id=temp_id)
        context = {'row' : row }
        return render(request, "student/profile.html", context)
    return redirect('/')

@login_required(login_url='/')
def student_stdmarks(request, pk):
    temp_id = request.user.username
    if Student.objects.filter(s_id=temp_id).exists():
        row = Marksheet.objects.filter(s_id=temp_id, exam_id=pk).order_by('-id')
        context = {'row' : row }
        return render(request, "student/stdmarks.html", context)
    return redirect('/')


#database connection
#login
#TODO
def signin(request):
    if request.method == 'POST':
        userselect= request.POST['login_select']
        userid= request.POST['login_id'].upper().strip()
        admin_id= request.POST['login_id'].strip()
        password = request.POST['login_pass'].strip()
        
        if userselect == 'admin':
            user = authenticate(request, username=admin_id, password=password)
            if user is not None and Profile.objects.filter(login_id=admin_id).exists() :
                login(request, user)
                if 'next' in request.POST:
                    return redirect(request.POST.get('next'))
                else:
                    return redirect('/administrator/dashboard')

            else:
                messages.warning(request, 'Invalid Credentials! Please check your User ID and Password')
                return redirect('/')

        elif userselect == 'reception':
            user = authenticate(request, username=userid, password=password)
            if user is not None and Staff.objects.filter(s_id=userid, type='Reception').exists() :
                login(request, user)
                if 'next' in request.POST:
                    return redirect(request.POST.get('next'))
                else:
                    return redirect('/reception/dashboard')

            else:
                messages.warning(request, 'Invalid Credentials! Please check your User ID and Password')
                return redirect('/')

        elif userselect == 'placement':
            user = authenticate(request, username=userid, password=password)
            if user is not None and Staff.objects.filter(s_id=userid, type='Placement').exists() :
                login(request, user)
                if 'next' in request.POST:
                    return redirect(request.POST.get('next'))
                else:
                    return redirect('/placement/dashboard')

            else:
                messages.warning(request, 'Invalid Credentials! Please check your User ID and Password')
                return redirect('/')

        elif userselect == 'student':
            user = authenticate(request, username=userid, password=password)
            if user is not None and Student.objects.filter(s_id=userid).exists():
                login(request, user)
                if 'next' in request.POST:
                    return redirect(request.POST.get('next'))
                else:
                    return redirect('/student/dashboard')
            else:
                messages.warning(request, 'Invalid Credentials! Please check your User ID and Password')
                return redirect('/')
            
        else:
            messages.warning(request, 'Invalid Credentials! Please check your User ID and Password')
            return redirect('/')

    return redirect('/')

#Logout TODO
def signout(request):
    if request.method == 'POST':
        logout(request)
        return redirect('/')
    return redirect('/')
    
#Admin
def adminEditProfile(request):
    if request.method == 'POST':
        try:
            # TODO
            edit=Profile.objects.get(id=1)
            temp_user = edit.login_id
            edit.name = request.POST['admin_name'].title()
            edit.email = request.POST['admin_email']
            edit.login_id = request.POST['admin_login_id'].strip()
            edit.password = request.POST['admin_pass'].strip()

            if User.objects.filter(username=temp_user).exists():
                user = User.objects.get(username = temp_user)
                test = authenticate(request, username=edit.login_id, password=edit.password )
                if test is None:                
                    user.username = edit.login_id
                    user.set_password(edit.password) 
                    user.save()
            
            edit.save()
            messages.success(request, 'Profile details are updated successfully!')
            return redirect('/administrator/profile')

        except:
            pass
            messages.error(request, 'OOPS! Profile details can\'t be updated!')
            return redirect('/administrator/profile')

    return redirect('/')



def addStudent(request):
    if request.method == 'POST':
        try:
            add = Student()
            ran = ''.join(random.choices(string.ascii_uppercase + string.digits, k = 5))  
            add.s_id = 'STD' + str(ran)
            add.name = request.POST['student_input_name'].title()
            add.gender = request.POST['student_input_gender']
            add.dob = request.POST['student_input_dob']
            add.show_dob =  add.dob
            add.email = request.POST['student_input_email']
            add.phone = request.POST['student_input_phone']
            add.course = request.POST['student_input_course']
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date
            add.semester = '1st'
            add.password = datetime.datetime.strftime(datetime.datetime.strptime(add.show_dob,'%Y-%m-%d'),'%d%m%y')
            row = Course.objects.get(name=add.course)
            add.total_amt =  int(row.ad_fee) + int(row.sem_fee)
            add.due_amt =  int(row.ad_fee) + int(row.sem_fee)
            add.paid_amt =  0
            User.objects.create_user(username=add.s_id, password=add.password)

            if len(request.FILES) > 0 :
                add.photo = request.FILES['student_input_photo']

            else:
                if(add.gender == 'Male'):
                    add.photo = 'uploads/male.jpg'
                elif(add.gender == 'Female'):
                    add.photo = 'uploads/female.jpg'
                elif(add.gender == 'Others'):
                    add.photo = 'uploads/others.jpg'

            mail_message = 'Greetings '+ add.name+'!\nYou have enrolled for ' + add.course + ' course. You can login with the credentials provided.\nYour Login ID is ' + add.s_id +' and Password is ' + add.password + '.'

            add.save()

            try:
                send_mail(
                   'Your registration and admission is confirmed',
                    mail_message,
                   'alok304n@gmail.com',
                   [add.email],
                   fail_silently=False
                )
                messages.success(request, 'Email send to Student successfully!')
            except:
                pass
                messages.error(request, 'OOPS! Email can\'t be send to Student!')
            messages.success(request, 'Student added successfully!')

            temp_id = request.user.username
            if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
                return redirect('/reception/student')
            else:
                return redirect('/administrator/student')
            
        except:
            pass
            messages.error(request, 'OOPS! Student can\'t be added!')
            temp_id = request.user.username
            if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
                return redirect('/reception/student')
            else:
                return redirect('/administrator/student')

    return redirect('/')


def editStudent(request):
    if request.method == 'POST':
        try:
            id=request.POST['student_update_id']
            edit=Student.objects.get(id=id)
            temp_id = edit.s_id
            edit.s_id = request.POST['student_update_sid'].upper().strip()
            edit.name = request.POST['student_update_name'].title()
            edit.gender = request.POST['student_update_gender']
            edit.dob = request.POST['student_update_dob']
            edit.show_dob =  edit.dob
            edit.email = request.POST['student_update_email']
            edit.phone = request.POST['student_update_phone']
            edit.date = request.POST['student_update_date']
            edit.show_date = edit.date

            temp_course = edit.course
            edit.course = request.POST['student_update_course']
            temp_semester = edit.semester
            edit.semester =  request.POST['student_update_semester']

            if temp_course != edit.course or temp_semester != edit.semester :
                row = Course.objects.get(name=edit.course)
                edit.total_amt =  int(row.ad_fee) + int(row.sem_fee)
                edit.due_amt =  int(row.ad_fee) + int(row.sem_fee)
                edit.paid_amt =  0

            edit.password =  request.POST['student_update_password'].strip()
            if User.objects.filter(username=temp_id).exists():
                user = User.objects.get(username = temp_id)
                user.username = edit.s_id
                user.set_password(edit.password) 
                user.save()


            if len(request.FILES) > 0 :
                if len(edit.photo) > 0 :
                    if edit.photo != 'uploads/male.jpg' and edit.photo != 'uploads/female.jpg' and edit.photo != 'uploads/others.jpg' :                    
                        os.remove(edit.photo.path)
                edit.photo = request.FILES['student_update_photo2']

            else:
                edit.photo = request.POST['student_update_photo']

            edit.save()
            messages.success(request, 'Student details are updated successfully!')
            temp_id = request.user.username
            if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
                return redirect('/reception/student')
            else:
                return redirect('/administrator/student')

        except:
            pass
            messages.error(request, 'OOPS! Student details can\'t be updated!')
            temp_id = request.user.username
            if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
                return redirect('/reception/student')
            else:
                return redirect('/administrator/student')

    return redirect('/')


def delStudent(request):
    if request.method == 'POST':
        try:
            id=request.POST['student_del_id']
            row=Student.objects.get(id=id)
            temp_id = row.s_id 
            if User.objects.filter(username=temp_id).exists():
                user = User.objects.get(username = temp_id)
                user.delete()

            if len(row.photo) > 0 :
                if row.photo != 'uploads/male.jpg' and row.photo != 'uploads/female.jpg' and row.photo != 'uploads/others.jpg' :                    
                    os.remove(row.photo.path)

            row.delete()

            messages.success(request, 'Student deleted successfully!')
            temp_id = request.user.username
            if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
                return redirect('/reception/student')
            else:
                return redirect('/administrator/student')

        except:
            pass
            messages.error(request, 'OOPS! Student can\'t be deleted!')
            temp_id = request.user.username
            if Staff.objects.filter(s_id=temp_id, type='Reception').exists():
                return redirect('/reception/student')
            else:
                return redirect('/administrator/student')
            
    return redirect('/')


def addStaff(request):
    if request.method == 'POST':
        try:
            add = Staff()
            ran = ''.join(random.choices(string.ascii_uppercase + string.digits, k = 5))  
            add.s_id = 'STF' + str(ran)
            add.name = request.POST['staff_input_name'].title()
            add.gender = request.POST['staff_input_gender']
            add.dob = request.POST['staff_input_dob']
            add.show_dob =  add.dob
            add.email = request.POST['staff_input_email']
            add.phone = request.POST['staff_input_phone']
            add.type = request.POST['staff_input_type']
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date
            add.password = datetime.datetime.strftime(datetime.datetime.strptime(add.show_dob,'%Y-%m-%d'),'%d%m%y')
            User.objects.create_user(username=add.s_id, password=add.password)

            if len(request.FILES) > 0 :
                add.photo = request.FILES['staff_input_photo']

            else:
                if(add.gender == 'Male'):
                    add.photo = 'uploads/male.jpg'
                elif(add.gender == 'Female'):
                    add.photo = 'uploads/female.jpg'
                elif(add.gender == 'Others'):
                    add.photo = 'uploads/others.jpg'


            mail_message = 'Greetings '+ add.name+'!\nWe have recruited you as a '+ add.type +' Manager. You can login with the credentials provided.\nYour Login ID is ' + add.s_id +' and Password is ' + add.password + '.'

            add.save()
            messages.success(request, 'Staff added successfully!')

            try:
                send_mail(
                   'Your have been added as a Staff',
                    mail_message,
                   'alok304n@gmail.com',
                   [add.email],
                   fail_silently=False
                )
                messages.success(request, 'Email send to Staff successfully!')
            except:
                pass
                messages.error(request, 'OOPS! Email can\'t be send to Staff!')
            return redirect('/administrator/staff')
            
        except:
            pass
            messages.error(request, 'OOPS! Staff can\'t be added!')
            return redirect('/administrator/staff')

    return redirect('/')


def editStaff(request):
    if request.method == 'POST':
        try:
            id=request.POST['staff_update_id']
            edit=Staff.objects.get(id=id)
            temp_id = edit.s_id
            edit.s_id = request.POST['staff_update_sid'].upper().strip()
            edit.name = request.POST['staff_update_name'].title()
            edit.gender = request.POST['staff_update_gender']
            edit.dob = request.POST['staff_update_dob']
            edit.show_dob =  edit.dob
            edit.email = request.POST['staff_update_email']
            edit.phone = request.POST['staff_update_phone']
            edit.type = request.POST['staff_update_type']
            edit.date = request.POST['staff_update_date']
            edit.show_date = edit.date
            edit.password =  request.POST['staff_update_password'].strip()
            if User.objects.filter(username=temp_id).exists():
                user = User.objects.get(username = temp_id)
                user.username = edit.s_id
                user.set_password(edit.password) 
                user.save()

            if len(request.FILES) > 0 :
                if len(edit.photo) > 0 :
                    if edit.photo != 'uploads/male.jpg' and edit.photo != 'uploads/female.jpg' and edit.photo != 'uploads/others.jpg' :                    
                        os.remove(edit.photo.path)
                edit.photo = request.FILES['staff_update_photo2']

            else:
                edit.photo = request.POST['staff_update_photo']

            edit.save()
            messages.success(request, 'Staff details are updated successfully!')
            return redirect('/administrator/staff')

        except:
            pass
            messages.error(request, 'OOPS! Staff details can\'t be updated!')
            return redirect('/administrator/staff')

    return redirect('/')

def delStaff(request):
    if request.method == 'POST':
        try:
            id=request.POST['staff_del_id']
            row=Staff.objects.get(id=id)
            temp_id = row.s_id 
            if User.objects.filter(username=temp_id).exists():
                user = User.objects.get(username = temp_id)
                user.delete()

            if len(row.photo) > 0 :
                if row.photo != 'uploads/male.jpg' and row.photo != 'uploads/female.jpg' and row.photo != 'uploads/others.jpg' :                    
                    os.remove(row.photo.path)

            row.delete()
            messages.success(request, 'Staff deleted successfully!')
            return redirect('/administrator/staff')

        except:
            pass
            messages.error(request, 'OOPS! Staff can\'t be deleted!')
            return redirect('/administrator/staff')
            
    return redirect('/')


def addCourse(request):
    if request.method == 'POST':
        try:
            add = Course()
            add.name = request.POST['course_input_name'].upper()
            add.duration = request.POST['course_input_duration']
            add.total_sem = str(int(add.duration)*2)
            add.ad_fee =  request.POST['course_input_adfee']
            add.sem_fee = request.POST['course_input_semfee']
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date

            add.save()
            messages.success(request, 'Course added successfully!')
            return redirect('/administrator/course')
            
        except:
            pass
            messages.error(request, 'OOPS! Course can\'t be added!')
            return redirect('/administrator/course')

    return redirect('/')

def editCourse(request):
    if request.method == 'POST':
        try:
            id=request.POST['course_update_id']
            edit=Course.objects.get(id=id)
            edit.name = request.POST['course_update_name'].upper()
            edit.duration = request.POST['course_update_duration']
            edit.total_sem =  str(int(edit.duration)*2)
            edit.ad_fee =  request.POST['course_update_adfee']
            edit.sem_fee = request.POST['course_update_semfee']
            edit.date = request.POST['course_update_date']
            edit.show_date = edit.date

            edit.save()
            messages.success(request, 'Course details are updated successfully!')
            return redirect('/administrator/course')

        except:
            pass
            messages.error(request, 'OOPS! Course details can\'t be updated!')
            return redirect('/administrator/course')

    return redirect('/')


def delCourse(request):
    if request.method == 'POST':
        try:
            id=request.POST['course_del_id']
            row=Course.objects.get(id=id)

            row.delete()
            messages.success(request, 'Course deleted successfully!')
            return redirect('/administrator/course')

        except:
            pass
            messages.error(request, 'OOPS! Course can\'t be deleted!')
            return redirect('/administrator/course')
            
    return redirect('/')


def addSubject(request):
    if request.method == 'POST':
        try:
            add = Subject()
            add.name = request.POST['subject_input_name'].title()
            add.course = request.POST['subject_input_course']
            add.semester =  request.POST['subject_input_semester']
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date
            ran = ''.join(random.choices(string.digits, k = 3))  
            add.code = add.course + str(ran)

            add.save()
            messages.success(request, 'Subject added successfully!')
            return redirect('/administrator/subject')
            
        except:
            pass
            messages.error(request, 'OOPS! Subject can\'t be added!')
            return redirect('/administrator/subject')

    return redirect('/')

def editSubject(request):
    if request.method == 'POST':
        try:
            id=request.POST['subject_update_id']
            edit=Subject.objects.get(id=id)
            edit.code = request.POST['subject_update_code']
            edit.name = request.POST['subject_update_name'].title()
            edit.course = request.POST['subject_update_course']
            edit.semester = request.POST['subject_update_semester']
            edit.date = request.POST['subject_update_date']
            edit.show_date = edit.date

            edit.save()
            messages.success(request, 'Subject details are updated successfully!')
            return redirect('/administrator/subject')

        except:
            pass
            messages.error(request, 'OOPS! Subject details can\'t be updated!')
            return redirect('/administrator/subject')

    return redirect('/')

def delSubject(request):
    if request.method == 'POST':
        try:
            id=request.POST['subject_del_id']
            row=Subject.objects.get(id=id)

            row.delete()
            messages.success(request, 'Subject deleted successfully!')
            return redirect('/administrator/subject')

        except:
            pass
            messages.error(request, 'OOPS! Subject can\'t be deleted!')
            return redirect('/administrator/subject')
            
    return redirect('/')


def addNotice(request):
    if request.method == 'POST':
        try:
            add = Notice()
            ran = ''.join(random.choices(string.digits, k = 5))  
            add.n_id = 'NTC' + str(ran)
            add.details = request.POST['notice_input_details'].title().strip()
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date

            add.save()
            messages.success(request, 'Notice added successfully!')
            return redirect('/administrator/notice')
            
        except:
            pass
            messages.error(request, 'OOPS! Notice can\'t be added!')
            return redirect('/administrator/notice')

    return redirect('/')

def editNotice(request):
    if request.method == 'POST':
        try:
            id=request.POST['notice_update_id']
            edit=Notice.objects.get(id=id)
            edit.n_id = request.POST['notice_update_nid']
            edit.details = request.POST['notice_update_details'].title().strip()
            edit.date = request.POST['notice_update_date']
            edit.show_date = edit.date

            edit.save()
            messages.success(request, 'Notice details are updated successfully!')
            return redirect('/administrator/notice')

        except:
            pass
            messages.error(request, 'OOPS! Notice details can\'t be updated!')
            return redirect('/administrator/notice')

    return redirect('/')

def delNotice(request):
    if request.method == 'POST':
        try:
            id=request.POST['notice_del_id']
            row=Notice.objects.get(id=id)

            row.delete()
            messages.success(request, 'Notice deleted successfully!')
            return redirect('/administrator/notice')

        except:
            pass
            messages.error(request, 'OOPS! Notice can\'t be deleted!')
            return redirect('/administrator/notice')
            
    return redirect('/')

#reception
def receptionEditProfile(request):
    if request.method == 'POST':
        try:
            s_id= request.user.username
            edit=Staff.objects.get(s_id=s_id)
            edit.phone = request.POST['reception_change_phone']
            edit.password = request.POST['reception_change_pass'].strip()
            temp_password = edit.password
            if User.objects.filter(username=s_id).exists():
                user = User.objects.get(username = s_id)
                test = authenticate(request, username=s_id, password=temp_password)
                if test is None:                
                    user.set_password(edit.password) 
                    user.save()
            
            if len(request.FILES) > 0 :
                if len(edit.photo) > 0 :
                    if edit.photo != 'uploads/male.jpg' and edit.photo != 'uploads/female.jpg' and edit.photo != 'uploads/others.jpg' :                    
                        os.remove(edit.photo.path)
                edit.photo = request.FILES['reception_change_photo2']

            else:
                edit.photo = request.POST['reception_change_photo']


            edit.save()
            messages.success(request, 'Profile details are updated successfully!')
            return redirect('/reception/profile')

        except:
            pass
            messages.error(request, 'OOPS! Profile details can\'t be updated!')
            return redirect('/reception/profile')

    return redirect('/')

def addExam(request):
    if request.method == 'POST':
        try:
            add = Exam()
            add.type = request.POST['exam_input_type'].title()
            add.course = request.POST['exam_input_course']
            add.semester =  request.POST['exam_input_semester']
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date

            add.save()
            messages.success(request, 'Exam added successfully!')
            return redirect('/reception/exam')
            
        except:
            pass
            messages.error(request, 'OOPS! Exam can\'t be added!')
            return redirect('/reception/exam')

    return redirect('/')

def editExam(request):
    if request.method == 'POST':
        try:
            id=request.POST['exam_update_id']
            edit=Exam.objects.get(id=id)
            edit.type = request.POST['exam_update_type'].title()
            edit.course = request.POST['exam_update_course']
            edit.semester = request.POST['exam_update_semester']
            edit.date = request.POST['exam_update_date']
            edit.show_date = edit.date

            edit.save()
            messages.success(request, 'Exam details are updated successfully!')
            return redirect('/reception/exam')

        except:
            pass
            messages.error(request, 'OOPS! Exam details can\'t be updated!')
            return redirect('/reception/exam')

    return redirect('/')

def delExam(request):
    if request.method == 'POST':
        try:
            id=request.POST['exam_del_id']
            row=Exam.objects.get(id=id)

            row.delete()
            messages.success(request, 'Exam deleted successfully!')
            return redirect('/reception/exam')

        except:
            pass
            messages.error(request, 'OOPS! Exam can\'t be deleted!')
            return redirect('/reception/exam')
            
    return redirect('/')

def payFee(request):
    if request.method == 'POST':
        try:
            add = Fees()
            ran = ''.join(random.choices(string.digits, k = 6))  
            add.t_id = 'TRS' + str(ran)
            add.fee_type =  request.POST['fees_type_amt']
            add.paid_amt =  request.POST['fees_pay_amt']
            add.total_amt =  request.POST['fees_total_amt']
            add.s_id = request.POST['student_id']

            row = Student.objects.get(id=add.s_id)
            row.due_amt -= int(add.paid_amt)
            add.due_amt = row.due_amt
            row.paid_amt += int(add.paid_amt)

            add.save()
            row.save()

            messages.success(request, 'Fees Paid successfully!')
            return redirect('/reception/students')

        except:
            pass
            messages.error(request, 'OOPS! Fees can\'t be Paid!')
            return redirect('/reception/students')
            
    return redirect('/')

def addMarksheet(request):
    if request.method == 'POST':
        try:
            sub_id = request.POST['exam_input_s_code']
            row = Subject.objects.get(id=sub_id)

            if Marksheet.objects.filter(exam_id=request.POST['exam_input_exam_id'] ,s_id= request.POST['exam_input_s_id'],s_code=row.code).exists():
                pass
                messages.info(request, 'Check Again! Marks already added!')
                return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

            add = Marksheet()
            add.s_code = row.code
            add.subject = row.name

            add.date = request.POST['exam_input_date']
            add.obtained_marks =  request.POST['exam_input_marks']
            add.total_marks = request.POST['exam_input_total']

            add.percentage =   ( int(add.obtained_marks) / int(add.total_marks) ) * 100

            add.exam_id =  request.POST['exam_input_exam_id']
            add.s_id = request.POST['exam_input_s_id']

            add.save()
            messages.success(request, 'Marks added successfully!')
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
            
        except: 
            pass
            messages.error(request, 'OOPS! Marks can\'t be added!')
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

    return redirect('/')

def delMarks(request):
    if request.method == 'POST':
        try:
            id=request.POST['marks_del_id']
            row=Marksheet.objects.get(id=id)

            row.delete()
            messages.success(request, 'Marks deleted successfully!')
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

        except:
            pass
            messages.error(request, 'OOPS! Marks can\'t be deleted!')
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
            
    return redirect('/')


#Placement
def placementEditProfile(request):
    if request.method == 'POST':
        try:
            s_id= request.user.username
            edit=Staff.objects.get(s_id=s_id)
            edit.phone = request.POST['placement_change_phone']
            edit.password = request.POST['placement_change_pass'].strip()
            temp_password = edit.password
            if User.objects.filter(username=s_id).exists():
                user = User.objects.get(username = s_id)
                test = authenticate(request, username=s_id, password=temp_password)
                if test is None:                
                    user.set_password(edit.password) 
                    user.save()
            
            if len(request.FILES) > 0 :
                if len(edit.photo) > 0 :
                    if edit.photo != 'uploads/male.jpg' and edit.photo != 'uploads/female.jpg' and edit.photo != 'uploads/others.jpg' :                    
                        os.remove(edit.photo.path)
                edit.photo = request.FILES['placement_change_photo2']

            else:
                edit.photo = request.POST['placement_change_photo']


            edit.save()
            messages.success(request, 'Profile details are updated successfully!')
            return redirect('/placement/profile')

        except:
            pass
            messages.error(request, 'OOPS! Profile details can\'t be updated!')
            return redirect('/placement/profile')

    return redirect('/')

def activeStudent(request):
    if request.method == 'POST':
        try:
            id=request.POST['student_get_id']
            row=Student.objects.get(id=id)

            if row.active == True :
                row.active = False
                messages.success(request, 'Student deselected successfully!')
            else:
                row.active = True  
                messages.success(request, 'Student selected successfully!')

            row.save()      
            return redirect('/placement/student')

        except:
            pass
            messages.error(request, 'OOPS! Student can\'t be selected!')
            return redirect('/placement/student')
            
    return redirect('/')

def sendInterViewMail(request):
    if request.method == 'POST':
        # try:
            comapny_name = request.POST['interview_input_company']
            interview_date = request.POST['interview_input_date']

            selected_students = Student.objects.filter(active=True)

            for student in selected_students:
                mail_message = 'Greetings '+ student.name+'!\nYou have chosen for the Interview of ' + comapny_name + ' Company.\nThe Schedule for Interview is ' + interview_date +'.'
                send_mail(
                   'Congrats! You have been selected for an Interview',
                    mail_message,
                   'alok304n@gmail.com',
                   [student.email],
                   fail_silently=False
                )

            messages.success(request, 'Email send to selected Students successfully!')
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

        # except:
        #     pass
        #     messages.error(request, 'OOPS! Email can\'t be send!')
        #     return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
            
    return redirect('/')

#Student
def studentEditProfile(request):
    if request.method == 'POST':
        try:
            s_id= request.user.username
            edit=Student.objects.get(s_id=s_id)
            edit.phone = request.POST['student_change_phone']
            edit.password = request.POST['student_change_pass'].strip()
            temp_password = edit.password
            if User.objects.filter(username=s_id).exists():
                user = User.objects.get(username = s_id)
                test = authenticate(request, username=s_id, password=temp_password)
                if test is None:                
                    user.set_password(edit.password) 
                    user.save()
            
            if len(request.FILES) > 0 :
                if len(edit.photo) > 0 :
                    if edit.photo != 'uploads/male.jpg' and edit.photo != 'uploads/female.jpg' and edit.photo != 'uploads/others.jpg' :                    
                        os.remove(edit.photo.path)
                edit.photo = request.FILES['student_change_photo2']

            else:
                edit.photo = request.POST['student_change_photo']


            edit.save()
            messages.success(request, 'Profile details are updated successfully!')
            return redirect('/student/profile')

        except:
            pass
            messages.error(request, 'OOPS! Profile details can\'t be updated!')
            return redirect('/student/profile')

    return redirect('/')

def addFeedback(request):
    if request.method == 'POST':
        try:
            add = Feedback()
            ran = ''.join(random.choices(string.digits, k = 5))  
            add.f_id = 'FBK' + str(ran)
            add.details =  request.POST['feedback_input_details'].title().strip()
            add.date = today.strftime("%Y-%m-%d")
            add.show_date = add.date
            temp_id = request.user.username
            row = Student.objects.get(s_id=temp_id)
            add.s_id = row.s_id
            add.s_name = row.name
            add.s_photo = row.photo

            add.save()
            messages.success(request, 'Feedback added successfully!')
            return redirect('/student/feedback')
            
        except:
            pass
            messages.error(request, 'OOPS! Feedback can\'t be added!')
            return redirect('/student/feedback')

    return redirect('/')

def delFeedback(request):
    if request.method == 'POST':
        try:
            id=request.POST['feedback_del_id']
            row=Feedback.objects.get(id=id)

            row.delete()
            messages.success(request, 'Feedback deleted successfully!')
            return redirect('/administrator/feedback')

        except:
            pass
            messages.error(request, 'OOPS! Feedback can\'t be deleted!')
            return redirect('/administrator/feedback')
            
    return redirect('/')
