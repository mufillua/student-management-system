//Auto expand nav
function myFunction(x) {
  const navbar = document.getElementById('navbar'),
    bodyPadding = document.getElementById('body-pd');

  if (x.matches) {
    // If media query matches
    navbar.classList.add('expander');
    bodyPadding.classList.add('body-pd');
  } else {
    navbar.classList.remove('expander');
    bodyPadding.classList.remove('body-pd');
  }
}
var x = window.matchMedia('(min-width: 1000px)');
myFunction(x); // Call listener function at run time
x.addListener(myFunction); // Attach listener function on state changes

// Expander Menu
const showMenu = (toggleID, navbarID, bodyID) => {
  const toggle = document.getElementById(toggleID),
    navbar = document.getElementById(navbarID),
    bodyPadding = document.getElementById(bodyID);

  if (toggle && navbar) {
    toggle.addEventListener('click', () => {
      navbar.classList.toggle('expander');
      bodyPadding.classList.toggle('body-pd');
    });
  }
};

showMenu('nav-toggle', 'navbar', 'body-pd');

// link active
const linkColor = document.querySelectorAll('.nav_link');
function colorLink() {
  linkColor.forEach(l => l.classList.remove('active'));
  this.classList.add('active');
}
linkColor.forEach(l => l.addEventListener('click', colorLink));

//table row showing limit set
function makeTableScroll() {
  var maxRows = 11;

  var table = document.getElementById('myTable');
  var wrapper = table.parentNode;
  var rowsInTable = table.rows.length;
  var height = 0;
  if (rowsInTable > maxRows) {
    for (var i = 0; i < maxRows; i++) {
      height += table.rows[i].clientHeight;
    }
    wrapper.style.height = height + 1 + 'px';
  }
}

//set date
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
   dd = '0' + dd;
}

if (mm < 10) {
   mm = '0' + mm;
} 
    
today = yyyy + '-' + mm + '-' + dd;

document.getElementById("student_input_dob").setAttribute("max", today);
document.getElementById("student_update_dob").setAttribute("max", today);
document.getElementById("student_update_date").setAttribute("max", today);
document.getElementById("staff_input_dob").setAttribute("max", today);
document.getElementById("staff_update_dob").setAttribute("max", today);
document.getElementById("staff_update_date").setAttribute("max", today);
document.getElementById("course_update_date").setAttribute("max", today);
document.getElementById("subject_update_date").setAttribute("max", today);
document.getElementById("notice_update_date").setAttribute("max", today);
document.getElementById("interview_input_date").setAttribute("min", today);

