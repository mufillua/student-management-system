$(document).ready(function () {
  //Table Input Search
  $('#mySearchInput').on('keyup', function () {
    var value = $(this).val().toLowerCase();

    $('#myTableBody tr').filter(function () {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
  });

  //Table Button Search
  $('#tbl_sel_btn').on('click', function () {
    var value1 = $('#dropDown1 :selected').val().toLowerCase();
    var value2 = $('#dropDown2 :selected').val().toLowerCase();

    $('#myTableBody tr').filter(function () {
      $(this).toggle(
        $(this).text().toLowerCase().indexOf(value1) > -1 &&
          $(this).text().toLowerCase().indexOf(value2) > -1
      );
    });
  });

//  Alert auto Hide
  $(".myAlert").fadeTo(5000, 500).slideUp(500, function(){
      $(".myAlert").slideUp(500);
  });

  //Admin
  //update Staff
  $('#modalForUpdateStaff').on('show.bs.modal', function (e) {
    var staff_id = $(e.relatedTarget).data('id');
    var staff_sid = $(e.relatedTarget).data('sid');
    var staff_photo = $(e.relatedTarget).data('photo');
    var staff_name = $(e.relatedTarget).data('name');
    var staff_gender = $(e.relatedTarget).data('gender');
    var staff_dob = $(e.relatedTarget).data('dob');
    var staff_email = $(e.relatedTarget).data('email');
    var staff_phone = $(e.relatedTarget).data('phone');
    var staff_type = $(e.relatedTarget).data('type');
    var staff_date = $(e.relatedTarget).data('date');
    var staff_password = $(e.relatedTarget).data('password');

    $(e.currentTarget).find('input[name="staff_update_id"]').val(staff_id);
    $(e.currentTarget).find('input[name="staff_update_sid"]').val(staff_sid);
    $(e.currentTarget)
      .find('input[name="staff_update_photo"]')
      .val(staff_photo);
    $(e.currentTarget).find('input[name="staff_update_name"]').val(staff_name);
    $(e.currentTarget)
      .find('select[name="staff_update_gender"]')
      .val(staff_gender);
    $(e.currentTarget).find('input[name="staff_update_dob"]').val(staff_dob);
    $(e.currentTarget)
      .find('input[name="staff_update_email"]')
      .val(staff_email);
    $(e.currentTarget)
      .find('input[name="staff_update_phone"]')
      .val(staff_phone);
    $(e.currentTarget).find('select[name="staff_update_type"]').val(staff_type);
    $(e.currentTarget).find('input[name="staff_update_date"]').val(staff_date);
    $(e.currentTarget)
      .find('input[name="staff_update_password"]')
      .val(staff_password);
  });

  //delete Staff
  $('#modalForDeleteStaff').on('show.bs.modal', function (e) {
    var staff_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="staff_del_id"]').val(staff_id);
  });

  //Table Button Search
  $('#tbl_sel_btn').on('click', function () {
    var value1 = $('#dropDown1 :selected').val().toLowerCase();
    var value2 = $('#dropDown2 :selected').val().toLowerCase();

    $('#myTableBody tr').filter(function () {
      $(this).toggle(
        $(this).text().toLowerCase().indexOf(value1) > -1 &&
          $(this).text().toLowerCase().indexOf(value2) > -1
      );
    });
  });

  //update Student
  $('#modalForUpdateStudent').on('show.bs.modal', function (e) {
    var student_id = $(e.relatedTarget).data('id');
    var student_sid = $(e.relatedTarget).data('sid');
    var student_photo = $(e.relatedTarget).data('photo');
    var student_name = $(e.relatedTarget).data('name');
    var student_gender = $(e.relatedTarget).data('gender');
    var student_dob = $(e.relatedTarget).data('dob');
    var student_email = $(e.relatedTarget).data('email');
    var student_phone = $(e.relatedTarget).data('phone');
    var student_course = $(e.relatedTarget).data('course');
    var student_semester = $(e.relatedTarget).data('semester');
    var student_date = $(e.relatedTarget).data('date');
    var student_password = $(e.relatedTarget).data('password');

    $(e.currentTarget).find('input[name="student_update_id"]').val(student_id);
    $(e.currentTarget)
      .find('input[name="student_update_sid"]')
      .val(student_sid);
    $(e.currentTarget)
      .find('input[name="student_update_photo"]')
      .val(student_photo);
    $(e.currentTarget)
      .find('input[name="student_update_name"]')
      .val(student_name);
    $(e.currentTarget)
      .find('select[name="student_update_gender"]')
      .val(student_gender);
    $(e.currentTarget)
      .find('input[name="student_update_dob"]')
      .val(student_dob);
    $(e.currentTarget)
      .find('input[name="student_update_email"]')
      .val(student_email);
    $(e.currentTarget)
      .find('input[name="student_update_phone"]')
      .val(student_phone);
    $(e.currentTarget)
      .find('select[name="student_update_course"]')
      .val(student_course);
    $(e.currentTarget)
      .find('select[name="student_update_semester"]')
      .val(student_semester);
    $(e.currentTarget)
      .find('input[name="student_update_date"]')
      .val(student_date);
    $(e.currentTarget)
      .find('input[name="student_update_password"]')
      .val(student_password);
  });

  //delete Student
  $('#modalForDeleteStudent').on('show.bs.modal', function (e) {
    var student_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="student_del_id"]').val(student_id);
  });

  //update Course
  $('#modalForUpdateCourse').on('show.bs.modal', function (e) {
    var course_id = $(e.relatedTarget).data('id');
    var course_name = $(e.relatedTarget).data('name');
    var course_duration = $(e.relatedTarget).data('duration');
    var course_semester = $(e.relatedTarget).data('semester');
    var course_adfee = $(e.relatedTarget).data('adfee');
    var course_semfee = $(e.relatedTarget).data('semfee');
    var course_date = $(e.relatedTarget).data('date');

    $(e.currentTarget).find('input[name="course_update_id"]').val(course_id);
    $(e.currentTarget)
      .find('input[name="course_update_name"]')
      .val(course_name);
    $(e.currentTarget)
      .find('select[name="course_update_duration"]')
      .val(course_duration);
    $(e.currentTarget)
      .find('input[name="course_update_semester"]')
      .val(course_semester);
    $(e.currentTarget)
      .find('input[name="course_update_adfee"]')
      .val(course_adfee);
    $(e.currentTarget)
      .find('input[name="course_update_semfee"]')
      .val(course_semfee);
    $(e.currentTarget)
      .find('input[name="course_update_date"]')
      .val(course_date);
  });

  //delete Course
  $('#modalForDeleteCourse').on('show.bs.modal', function (e) {
    var course_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="course_del_id"]').val(course_id);
  });

  //update Subject
  $('#modalForUpdateSubject').on('show.bs.modal', function (e) {
    var subject_id = $(e.relatedTarget).data('id');
    var subject_code = $(e.relatedTarget).data('code');
    var subject_name = $(e.relatedTarget).data('name');
    var subject_course = $(e.relatedTarget).data('course');
    var subject_semester = $(e.relatedTarget).data('semester');
    var subject_date = $(e.relatedTarget).data('date');

    $(e.currentTarget).find('input[name="subject_update_id"]').val(subject_id);
    $(e.currentTarget)
      .find('input[name="subject_update_code"]')
      .val(subject_code);
    $(e.currentTarget)
      .find('input[name="subject_update_name"]')
      .val(subject_name);
    $(e.currentTarget)
      .find('select[name="subject_update_course"]')
      .val(subject_course);
    $(e.currentTarget)
      .find('select[name="subject_update_semester"]')
      .val(subject_semester);
    $(e.currentTarget)
      .find('input[name="subject_update_date"]')
      .val(subject_date);
  });

  //delete Subject
  $('#modalForDeleteSubject').on('show.bs.modal', function (e) {
    var subject_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="subject_del_id"]').val(subject_id);
  });

  //update Notice
  $('#modalForUpdateNotice').on('show.bs.modal', function (e) {
    var notice_id = $(e.relatedTarget).data('id');
    var notice_nid = $(e.relatedTarget).data('nid');
    var notice_name = $(e.relatedTarget).data('details');
    var notice_date = $(e.relatedTarget).data('date');

    $(e.currentTarget).find('input[name="notice_update_id"]').val(notice_id);
    $(e.currentTarget).find('input[name="notice_update_nid"]').val(notice_nid);
    $(e.currentTarget)
      .find('textarea[name="notice_update_details"]')
      .val(notice_name);
    $(e.currentTarget)
      .find('input[name="notice_update_date"]')
      .val(notice_date);
  });

  //delete Notice
  $('#modalForDeleteNotice').on('show.bs.modal', function (e) {
    var notice_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="notice_del_id"]').val(notice_id);
  });

  //delete Feedback
  $('#modalForDeleteFeedback').on('show.bs.modal', function (e) {
    var feedback_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="feedback_del_id"]').val(feedback_id);
  });

  //Reception
  
  //update Exam
  $('#modalForUpdateExam').on('show.bs.modal', function (e) {
    var exam_id = $(e.relatedTarget).data('id');
    var exam_type = $(e.relatedTarget).data('type');
    var exam_course = $(e.relatedTarget).data('course');
    var exam_semester = $(e.relatedTarget).data('semester');
    var exam_date = $(e.relatedTarget).data('date');

    $(e.currentTarget).find('input[name="exam_update_id"]').val(exam_id);
    $(e.currentTarget).find('input[name="exam_update_type"]').val(exam_type);
    $(e.currentTarget)
      .find('select[name="exam_update_course"]')
      .val(exam_course);
    $(e.currentTarget)
      .find('select[name="exam_update_semester"]')
      .val(exam_semester);
    $(e.currentTarget).find('input[name="exam_update_date"]').val(exam_date);
  });

  //delete Exam
  $('#modalForDeleteExam').on('show.bs.modal', function (e) {
    var exam_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="exam_del_id"]').val(exam_id);
  });

  //Input Marks
  $('#modalForInputMarks').on('show.bs.modal', function (e) {
    var s_id = $(e.relatedTarget).data('sid');
    $(e.currentTarget).find('input[name="exam_input_s_id"]').val(s_id);
  });

  //delete Marks
  $('#modalForDeleteMarks').on('show.bs.modal', function (e) {
    var marks_id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="marks_del_id"]').val(marks_id);
  });

  //Pay Fees
  $('#modalForPayFees').on('show.bs.modal', function (e) {
    var id = $(e.relatedTarget).data('id');
    var due_amt = $(e.relatedTarget).data('due');
    var total_amt = $(e.relatedTarget).data('total');

    $(e.currentTarget).find('input[name="student_id"]').val(id);
    $(e.currentTarget).find('input[name="fees_total_amt"]').val(total_amt);
    $(e.currentTarget).find('input[name="fees_pay_amt"]').attr('max', due_amt);
    $(e.currentTarget)
      .find('input[name="fees_due_amt"]')
      .val(due_amt);
  });
});
