from django.urls import path
from . import views

urlpatterns = [
    #login page
    path("", views.index, name='index'),
    path("login", views.signin, name='login'),
    path("logout", views.signout, name='logout'),

    #admin pages
    path(r'administrator/dashboard', views.admin_dashboard, name='admin_dashboard'),
    path(r'administrator/course', views.admin_course, name='admin_course'),
    path(r'administrator/feedback', views.admin_feedback, name='admin_feedback'),
    path(r'administrator/students', views.admin_fees, name='admin_fees'),
    path(r'administrator/exams', views.admin_marks, name='admin_marks'),
    path(r'administrator/notice', views.admin_notice, name='admin_notice'),
    path(r'administrator/profile', views.admin_profile, name='admin_profile'),
    path(r'administrator/staff', views.admin_staff, name='admin_staff'),
    path(r'administrator/staff/staffprofileview/<str:pk>', views.admin_staffprofileview, name='admin_staffprofileview'),
    path(r'administrator/exams/students/<str:course> <str:sem> <str:exam_id>', views.admin_stdmarks, name='admin_stdmarks'),
    path(r'administrator/student', views.admin_student, name='admin_student'),
    path(r'administrator/student/stdprofileview/<str:pk>', views.admin_stdprofileview, name='admin_stdprofileview'),
    path(r'administrator/subject', views.admin_subject, name='admin_subject'),
    path(r'administrator/exams/students/marksheet/<str:exam_id> <str:s_id>', views.admin_mark_details, name='admin_mark_details'),
    path(r'administrator/students/fees/<str:pk>', views.admin_fee_details, name='admin_fee_details'),
    #admin db
    path(r'administrator/editProfile', views.adminEditProfile, name='adminEditProfile'),
    path(r'administrator/addStudent', views.addStudent, name='addStudent'),
    path(r'administrator/editStudent', views.editStudent, name='editStudent'),
    path(r'administrator/delStudent', views.delStudent, name='delStudent'),
    path(r'administrator/addStaff', views.addStaff, name='addStaff'),
    path(r'administrator/editStaff', views.editStaff, name='editStaff'),
    path(r'administrator/delStaff', views.delStaff, name='delStaff'),
    path(r'administrator/addCourse', views.addCourse, name='addCourse'),
    path(r'administrator/editCourse', views.editCourse, name='editCourse'),
    path(r'administrator/delCourse', views.delCourse, name='delCourse'),
    path(r'administrator/addSubject', views.addSubject, name='addSubject'),
    path(r'administrator/editSubject', views.editSubject, name='editSubject'),
    path(r'administrator/delSubject', views.delSubject, name='delSubject'),
    path(r'administrator/addNotice', views.addNotice, name='addNotice'),
    path(r'administrator/editNotice', views.editNotice, name='editNotice'),
    path(r'administrator/delNotice', views.delNotice, name='delNotice'),
    
    #reception pages
    path(r'reception/dashboard', views.reception_dashboard, name='reception_dashboard'),
    path(r'reception/exam', views.reception_exam, name='reception_exam'),
    path(r'reception/feedback', views.reception_feedback, name='reception_feedback'),
    path(r'reception/students', views.reception_fees, name='reception_fees'),
    path(r'reception/exams', views.reception_marks, name='reception_marks'),
    path(r'reception/notice', views.reception_notice, name='reception_notice'),
    path(r'reception/profile', views.reception_profile, name='reception_profile'),
    path(r'reception/student', views.reception_student, name='reception_student'),
    path(r'reception/exams/students/<str:course> <str:sem> <str:exam_id>', views.reception_stdmarks, name='reception_stdmarks'),
    path(r'reception/exams/students/marks/<str:exam_id> <str:s_id>', views.reception_viewmarks, name='reception_viewmarks'),
    path(r'reception/students/fees/<str:pk>', views.reception_fee_details, name='reception_fee_details'),
    #reception DB
    path(r'reception/editProfile', views.receptionEditProfile, name='receptionEditProfile'),
    path(r'reception/addExam', views.addExam, name='addExam'),
    path(r'reception/editExam', views.editExam, name='editExam'),
    path(r'reception/delExam', views.delExam, name='delExam'),
    path(r'reception/payFee', views.payFee, name='payFee'),
    path(r'reception/addMarksheet', views.addMarksheet, name='addMarksheet'),
    path(r'reception/delMarks', views.delMarks, name='delMarks'),
    path(r'reception/sendInterViewMail', views.sendInterViewMail, name='sendInterViewMail'),

    #placement pages
    path(r'placement/dashboard', views.placement_dashboard, name='placement_dashboard'),
    path(r'placement/profile', views.placement_profile, name='placement_profile'),
    path(r'placement/student', views.placement_student, name='placement_student'),
    path(r'placement/notice', views.placement_notice, name='placement_notice'),
    path(r'placement/feedback', views.placement_feedback, name='placement_feedback'),
    path(r'placement/exams', views.placement_marks, name='placement_marks'),
    path(r'placement/exams/students/<str:course> <str:sem> <str:exam_id>', views.placement_stdmarks, name='placement_stdmarks'),
    path(r'placement/exams/students/marksheet/<str:exam_id> <str:s_id>', views.placement_mark_details, name='placement_mark_details'),
    path(r'placement/students', views.placement_fees, name='placement_fees'),
    path(r'placement/students/fees/<str:pk>', views.placement_fee_details, name='placement_fee_details'),
    #placement DB
    path(r'placement/editProfile', views.placementEditProfile, name='placementEditProfile'),
    path(r'placement/activeStudent', views.activeStudent, name='activeStudent'),

    #student pages
    path(r'student/dashboard', views.student_dashboard, name='student_dashboard'),
    path(r'student/feedback', views.student_feedback, name='student_feedback'),
    path(r'student/fees', views.student_fees, name='student_fees'),
    path(r'student/exam', views.student_marks, name='student_marks'),
    path(r'student/notice', views.student_notice, name='student_notice'),
    path(r'student/profile', views.student_profile, name='student_profile'),
    path(r'student/exam/marks/<str:pk>', views.student_stdmarks, name='student_stdmarks'),
    #student DB
    path(r'student/editProfile', views.studentEditProfile, name='studentEditProfile'),
    path(r'reception/addFeedback', views.addFeedback, name='addFeedback'),
    path(r'reception/delFeedback', views.delFeedback, name='delFeedback'),
]