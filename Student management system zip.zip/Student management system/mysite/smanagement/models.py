from datetime import date
from django.db import models
import datetime
import os

def filepath(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    filename = "%s%s" % (timeNow, old_filename)
    path = 'uploads/'
    return os.path.join(path , filename)


# Create your models here.
class Profile(models.Model):  
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=50)
    login_id= models.CharField(max_length=50, unique=True)
    password= models.CharField(max_length=50)
    class Meta:
        db_table="Profile"

class Student(models.Model):  
    s_id = models.CharField(max_length=50, unique=True)
    photo = models.ImageField(upload_to=filepath, null=True, blank=True)
    name = models.CharField(max_length=50)
    gender = models.CharField(max_length=50)
    dob= models.CharField(max_length=50)
    show_dob= models.DateField(null=True)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    course = models.CharField(max_length=50)
    semester = models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    password = models.CharField(max_length=50)
    due_amt = models.IntegerField(null=True,)
    paid_amt = models.IntegerField(null=True)
    total_amt = models.IntegerField(null=True)
    active = models.BooleanField(default=False)
    class Meta:
        db_table="Student"

class Staff(models.Model):  
    s_id = models.CharField(max_length=50, unique=True)
    photo = models.ImageField(upload_to=filepath, null=True, blank=True)
    name = models.CharField(max_length=50)
    gender = models.CharField(max_length=50)
    dob= models.CharField(max_length=50)
    show_dob= models.DateField(null=True)
    type = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    password = models.CharField(max_length=50)
    class Meta:
        db_table="Staff"

class Course(models.Model):  
    name = models.CharField(max_length=50, unique=True)
    duration = models.CharField(max_length=50)
    total_sem= models.CharField(max_length=50)
    ad_fee= models.CharField(max_length=50)
    sem_fee= models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    class Meta:
        db_table="Course"

class Subject(models.Model):  
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=50)
    course= models.CharField(max_length=50)
    semester= models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    class Meta:
        db_table="Subject"

class Notice(models.Model):  
    n_id = models.CharField(max_length=50, unique=True)
    details = models.CharField(max_length=500)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    class Meta:
        db_table="Notice"

class Exam(models.Model):  
    type = models.CharField(max_length=50)
    course= models.CharField(max_length=50)
    semester= models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    class Meta:
        db_table="Exam"

class Feedback(models.Model):  
    f_id = models.CharField(max_length=50)
    details= models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    show_date = models.DateField(null=True)
    s_id = models.CharField(max_length=50)
    s_name = models.CharField(max_length=50)
    s_photo = models.CharField(max_length=50)
    class Meta:
        db_table="Feedback"

class Fees(models.Model):  
    t_id = models.CharField(max_length=50)
    fee_type= models.CharField(max_length=50)
    paid_amt = models.IntegerField(null=True)
    due_amt = models.IntegerField(null=True)
    total_amt = models.IntegerField(null=True)
    time = models.TimeField(auto_now=True, null=True)
    date = models.DateField(auto_now=True, null=True)
    s_id = models.CharField(max_length=50)
    class Meta:
        db_table="Fees"

class Marksheet(models.Model):  
    s_code = models.CharField(max_length=50)
    subject= models.CharField(max_length=50)
    date = models.DateField(null=True)
    obtained_marks = models.IntegerField(null=True)
    total_marks = models.IntegerField(null=True)
    percentage = models.IntegerField(null=True)
    exam_id = models.CharField(max_length=50)
    s_id = models.CharField(max_length=50)
    class Meta:
        db_table="Marksheet"

