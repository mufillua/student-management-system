from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Student)
admin.site.register(Staff)
admin.site.register(Course)
admin.site.register(Subject)
admin.site.register(Notice)
admin.site.register(Profile)
admin.site.register(Exam)
admin.site.register(Feedback)
admin.site.register(Fees)
admin.site.register(Marksheet)
